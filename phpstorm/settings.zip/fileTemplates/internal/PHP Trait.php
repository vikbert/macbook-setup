<?php

#parse("PHP File Header.php")

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

/**
 * @author Xun Zhou <xun.zhou@lidl.com>
 */
trait ${NAME} 
{
}